--------------------------------------------------------------------------------
Version 1.0.0
--------------------------------------------------------------------------------

This folder contains the code examples from the book "Pro JavaScript Design 
Patterns" by Ross Harmes and Dustin Diaz. 

The latest version of this code can always be downloaded at:

http://jsdesignpatterns.com/code.zip

and at the Apress website:

http://apress.com/book/view/159059908x

Questions and corrections can be sent to ross@jsdesignpatterns.com and 
dustin@jsdesignpatterns.com.